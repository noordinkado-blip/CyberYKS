# CyberYKS Android app

This project contains a Kivy-based Android app with:
- Password strength checklist
- Show/hide password field
- Random password generator (uses Python `secrets`)
- Local security report

## Important privacy note
Use sample passwords only. The app does not send passwords to a server or save them to a file. The score is a basic estimate, not a guarantee of security.

## Files
- `main.py` — app source code
- `buildozer.spec` — Android packaging configuration

## Build on Linux / GitHub Codespaces
Buildozer needs a Linux build environment. On a Linux environment with the required Android SDK/NDK dependencies installed:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install buildozer cython
buildozer android debug
```

The APK is created in the `bin/` directory. Its generated filename may include the version and architecture. After verifying the APK exists, it can be renamed to `CyberYKS.apk`.

Codespaces and other cloud build services may have free usage limits and may ask for billing details. Do not confirm a paid plan unless you choose to.
