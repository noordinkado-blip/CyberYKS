[app]

title = CyberYKS
package.name = cyberyks
package.domain = org.cyberyks

source.dir = .
source.include_exts = py,kv,png,jpg,atlas
version = 1.0.0

requirements = python3,kivy

orientation = portrait
fullscreen = 0

# Android build settings
android.minapi = 23
android.api = 35
android.ndk = 27b
android.accept_sdk_license = True
android.archs = arm64-v8a

# No special Android permissions are needed for this app.
android.permissions =

# Buildozer settings
[buildozer]
log_level = 2
warn_on_root = 1
