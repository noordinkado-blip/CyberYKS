import secrets
import string

from kivy.app import App
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.utils import get_color_from_hex
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, RoundedRectangle


BG = "#100D1C"
PANEL = "#211B32"
PURPLE = "#8053D6"
LIGHT = "#D8C8FF"
WHITE = "#FFFFFF"
GREEN = "#55DD99"
YELLOW = "#FFC857"
RED = "#FF7777"


class CyberYKS(App):
    def build(self):
        Window.clearcolor = get_color_from_hex(BG)

        root = BoxLayout(
            orientation="vertical",
            padding=dp(16),
            spacing=dp(10),
        )

        title = Label(
            text="[color=AA80FF]CyberYKS[/color]",
            markup=True,
            font_size="32sp",
            bold=True,
            size_hint_y=None,
            height=dp(54),
        )
        root.add_widget(title)

        subtitle = Label(
            text="MOBILE SECURITY TOOLKIT",
            color=get_color_from_hex(LIGHT),
            font_size="12sp",
            size_hint_y=None,
            height=dp(24),
        )
        root.add_widget(subtitle)

        scroll = ScrollView()
        content = BoxLayout(
            orientation="vertical",
            spacing=dp(12),
            size_hint_y=None,
            padding=(0, dp(6), 0, dp(10)),
        )
        content.bind(minimum_height=content.setter("height"))

        content.add_widget(self.section_label("PASSWORD CHECKER"))

        self.password_input = TextInput(
            hint_text="Enter a sample password",
            password=True,
            multiline=False,
            size_hint_y=None,
            height=dp(52),
            padding=(dp(12), dp(14)),
            background_normal="",
            background_active="",
            background_color=get_color_from_hex(PANEL),
            foreground_color=get_color_from_hex(WHITE),
            hint_text_color=get_color_from_hex("#A99BBC"),
            cursor_color=get_color_from_hex(LIGHT),
        )
        content.add_widget(self.password_input)

        row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        self.show_button = self.make_button("SHOW", "#49346D")
        self.show_button.bind(on_press=self.toggle_password)
        row.add_widget(self.show_button)

        check_button = self.make_button("CHECK PASSWORD", PURPLE)
        check_button.bind(on_press=self.check_password)
        row.add_widget(check_button)
        content.add_widget(row)

        self.score_label = Label(
            text="SECURITY SCORE: -- / 5",
            color=get_color_from_hex(LIGHT),
            font_size="18sp",
            bold=True,
            size_hint_y=None,
            height=dp(36),
        )
        content.add_widget(self.score_label)

        self.report_label = Label(
            text="Your security report will appear here.",
            markup=True,
            color=get_color_from_hex(WHITE),
            font_size="14sp",
            halign="left",
            valign="middle",
            size_hint_y=None,
        )
        self.report_label.bind(
            texture_size=lambda widget, size: setattr(widget, "height", size[1] + dp(20))
        )
        self.report_label.bind(size=self._update_text_size)
        content.add_widget(self.report_label)

        content.add_widget(self.section_label("PASSWORD GENERATOR"))
        gen_info = Label(
            text="Generate a random example password on this device.",
            color=get_color_from_hex(LIGHT),
            font_size="12sp",
            size_hint_y=None,
            height=dp(28),
        )
        content.add_widget(gen_info)

        self.generated_input = TextInput(
            hint_text="Generated password",
            readonly=True,
            multiline=False,
            size_hint_y=None,
            height=dp(52),
            padding=(dp(12), dp(14)),
            background_normal="",
            background_active="",
            background_color=get_color_from_hex(PANEL),
            foreground_color=get_color_from_hex(WHITE),
            hint_text_color=get_color_from_hex("#A99BBC"),
        )
        content.add_widget(self.generated_input)

        gen_row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        generate_button = self.make_button("GENERATE", PURPLE)
        generate_button.bind(on_press=self.generate_password)
        gen_row.add_widget(generate_button)

        copy_button = self.make_button("USE IN CHECKER", "#49346D")
        copy_button.bind(on_press=self.use_generated)
        gen_row.add_widget(copy_button)
        content.add_widget(gen_row)

        clear_button = self.make_button("CLEAR ALL", "#49346D")
        clear_button.bind(on_press=self.clear_all)
        content.add_widget(clear_button)

        footer = Label(
            text="CyberYKS V1  |  Password tools run locally",
            color=get_color_from_hex("#9B8AB5"),
            font_size="10sp",
            size_hint_y=None,
            height=dp(28),
        )
        content.add_widget(footer)

        scroll.add_widget(content)
        root.add_widget(scroll)
        return root

    def _update_text_size(self, widget, size):
        widget.text_size = (size[0], None)

    def section_label(self, text):
        return Label(
            text=f"[color=AA80FF]{text}[/color]",
            markup=True,
            bold=True,
            font_size="15sp",
            halign="left",
            size_hint_y=None,
            height=dp(32),
        )

    def make_button(self, text, color):
        button = Button(
            text=text,
            size_hint_y=None,
            height=dp(48),
            background_normal="",
            background_down="",
            background_color=get_color_from_hex(color),
            color=get_color_from_hex(WHITE),
            bold=True,
            font_size="13sp",
        )
        return button

    def toggle_password(self, instance):
        self.password_input.password = not self.password_input.password
        self.show_button.text = (
            "SHOW" if self.password_input.password else "HIDE"
        )

    def check_password(self, instance):
        password = self.password_input.text
        if not password:
            self.score_label.text = "SECURITY SCORE: -- / 5"
            self.report_label.text = "[color=FFC857]Enter a sample password first.[/color]"
            return

        checks = [
            ("At least 8 characters", len(password) >= 8),
            ("Contains uppercase letter", any(c.isupper() for c in password)),
            ("Contains lowercase letter", any(c.islower() for c in password)),
            ("Contains a number", any(c.isdigit() for c in password)),
            ("Contains a symbol", any(not c.isalnum() for c in password)),
        ]
        score = sum(1 for _, passed in checks)

        if score <= 2:
            strength, color = "WEAK", RED
        elif score <= 4:
            strength, color = "MEDIUM", YELLOW
        else:
            strength, color = "STRONG", GREEN

        lines = []
        for name, passed in checks:
            mark = "[color=55DD99]OK[/color]" if passed else "[color=FF7777]MISSING[/color]"
            lines.append(f"{mark}  {name}")

        self.score_label.text = f"SECURITY SCORE: {score} / 5"
        self.report_label.text = (
            f"[b][color={color}]STRENGTH: {strength}[/color][/b]\n\n"
            + "\n".join(lines)
            + "\n\n[color=BCA8E8]This is a basic estimate, not a guarantee "
              "that a password is secure.[/color]"
        )
        self.report_label.markup = True

    def generate_password(self, instance):
        alphabet = string.ascii_letters + string.digits + "!@#$%&*+-_?"
        # Generate a random 16-character sample using Python's secrets module.
        password = "".join(secrets.choice(alphabet) for _ in range(16))
        self.generated_input.text = password

    def use_generated(self, instance):
        if self.generated_input.text:
            self.password_input.text = self.generated_input.text
            self.password_input.password = False
            self.show_button.text = "HIDE"

    def clear_all(self, instance):
        self.password_input.text = ""
        self.password_input.password = True
        self.show_button.text = "SHOW"
        self.generated_input.text = ""
        self.score_label.text = "SECURITY SCORE: -- / 5"
        self.report_label.text = "Your security report will appear here."


if __name__ == "__main__":
    CyberYKS().run()
